//
//  Login.swift
//  Patronage
//
//  Created by Naguru Abdur,Rehaman on 4/30/22.
//

import UIKit

struct LoginModel : Encodable {
    let login : String
    let password : String
}
