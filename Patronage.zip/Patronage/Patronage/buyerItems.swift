//
//  buyerItems.swift
//  Patronage
//
//  Created by student on 4/28/22.
//

import Foundation
struct buyerSection {
    var Category  = ""
        
    var items_Array :[buyerItems] = []

        
}
struct buyerItems{
  var  itemName = ""
    var itemImage = ""
    var itemInfo = " "
    var itemQuantity = " "
    var itemPrice = " "
    
}
let item1  = buyerSection( Category: "Vegetables", items_Array: [buyerItems(itemName:"Potatoes",itemImage:"potato",itemInfo:"The potato is one of some 150 tuber-bearing species of the genus Solanum (a tuber is the swollen end of an underground stem). The compound leaves are spirally arranged; each leaf is 20–30 cm (about 8–12 inches) long and consists of a terminal leaflet and two to four pairs of leaflets.", itemQuantity: "2tons", itemPrice: "$56")])
let item2  = buyerSection( Category: "Fruits", items_Array: [buyerItems(itemName:"PineApple",itemImage:"pine",itemInfo:"The potato is one of some 150 tuber-bearing species of the genus Solanum (a tuber is the swollen end of an underground stem). The compound leaves are spirally arranged; each leaf is 20–30 cm (about 8–12 inches) long and consists of a terminal leaflet and two to four pairs of leaflets.", itemQuantity: "1Ton", itemPrice: "$65")])

let buyer_items = [item1, item2]
