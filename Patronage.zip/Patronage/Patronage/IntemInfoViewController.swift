//
//  IntemInfoViewController.swift
//  Patronage
//
//  Created by student on 4/29/22.
//

import UIKit

class IntemInfoViewController: UIViewController {
    var buyerItem : buyerItems = buyerItems()
    
    @IBOutlet weak var ItemImageOutlet: UIImageView!
    
    
    @IBOutlet weak var itemNameOutlet: UILabel!
    
    @IBOutlet weak var itemInfoOutlet: UILabel!
    
    @IBOutlet weak var itemQuantityOutlet: UILabel!
    
    @IBOutlet weak var itemPriceOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        ItemImageOutlet.image = UIImage(named: buyerItem.itemImage)
        itemInfoOutlet.text = " "
        itemQuantityOutlet.text = " "
        itemPriceOutlet.text = " "
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClickbutton(_ sender: UIButton) {
        itemInfoOutlet.text = buyerItem.itemInfo
        itemQuantityOutlet.text  =  "Item Quantity \(buyerItem.itemQuantity)"
        itemPriceOutlet.text  =  "Item Price \(buyerItem.itemPrice)"

    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
