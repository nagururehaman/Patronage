//
//  Constant.swift
//  Patronage
//
//  Created by Naguru Abdur,Rehaman on 4/29/22.
//

import Foundation


let app_id = "49E20D38-48BC-655F-FF0A-BD4C613C6600"
let rest_key = "C6F9FBB8-0A33-4040-9D6D-427BF495283D"
let base_url = "https://api.backendless.com/\(app_id)/\(rest_key)/users/"
let register_url = "\(base_url)register"
let login_url = "\(base_url)login"
